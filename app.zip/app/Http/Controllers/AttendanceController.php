<?php

namespace App\Http\Controllers;

use App\Models\Attendance;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;

class AttendanceController extends Controller
{
    // تسجيل الحضور
    public function checkIn(Request $request)
    {
        $user = Auth::user();
        $today = Carbon::today();

        // تحقق من أن الموظف ليس عنده جلسة مفتوحة بدون خروج
        $openSession = Attendance::where('user_id', $user->id)
            ->whereDate('work_date', $today)
            ->whereNull('check_out_at')
            ->first();

        if ($openSession) {
            return response()->json([
                'status'  => false,
                'message' => 'لديك حضور مسجل ولم يتم تسجيل الانصراف بعد.',
            ], 422);
        }

        // تحقق من الموقع (سنكتب الدالة بعد قليل)
        $isInside = $this->isInsideOffice($request);

        if (! $isInside) {
            return response()->json([
                'status'  => false,
                'message' => 'لا يمكنك تسجيل الحضور إلا من داخل الشركة.',
            ], 403);
        }

        $attendance = Attendance::create([
            'id'          => (string) Str::uuid(),
            'user_id'     => $user->id,
            'work_date'   => $today,
            'check_in_at' => now(),
            'ip_address'  => $request->ip(),
            'lat'         => $request->input('lat'),
            'lng'         => $request->input('lng'),
            'is_inside_office' => $isInside,
            'source'      => $request->input('source', 'web'),
        ]);

        return response()->json([
            'status'  => true,
            'message' => 'تم تسجيل الحضور بنجاح.',
            'data'    => $attendance,
        ]);
    }

    // تسجيل الانصراف
    public function checkOut(Request $request)
    {
        $user = Auth::user();
        $today = Carbon::today();

        // نبحث عن آخر جلسة مفتوحة بدون وقت انصراف
        $attendance = Attendance::where('user_id', $user->id)
            ->whereDate('work_date', $today)
            ->whereNull('check_out_at')
            ->orderBy('check_in_at', 'desc')
            ->first();

        if (! $attendance) {
            return response()->json([
                'status'  => false,
                'message' => 'لا يوجد حضور مفتوح لتسجيل الانصراف.',
            ], 422);
        }

        $attendance->update([
            'check_out_at' => now(),
        ]);

        return response()->json([
            'status'  => true,
            'message' => 'تم تسجيل الانصراف بنجاح.',
            'data'    => $attendance,
        ]);
    }

    // حساب إجمالي دقائق اليوم للموظف الحالي
    public function todaySummary()
    {
        $user = Auth::user();
        $today = Carbon::today();

        $attendances = Attendance::where('user_id', $user->id)
            ->whereDate('work_date', $today)
            ->get();

        $totalMinutes = $attendances->sum->session_minutes;

        return response()->json([
            'status'        => true,
            'date'          => $today->toDateString(),
            'total_minutes' => $totalMinutes,
            'total_hours'   => round($totalMinutes / 60, 2),
        ]);
    }

    /**
     * ✅ التحقق أن الحضور من داخل الشركة
     * سنضبطها تحت حسب الحل الذي تفضله
     */
    private function isInsideOffice(Request $request): bool
    {
        // مكان الشركة (إحداثيات تقريبية - غيّرها لموقعك)
        $officeLat = 32.6150000; // مثال
        $officeLng = 44.0240000; // مثال
        $maxDistanceMeters = 100; // نصف قطر 100 متر مثلاً

        $userLat = $request->input('lat');
        $userLng = $request->input('lng');

        if (! $userLat || ! $userLng) {
            return false;
        }

        $distance = $this->distanceInMeters($officeLat, $officeLng, $userLat, $userLng);
        return $distance <= $maxDistanceMeters;
    }

     private function distanceInMeters($lat1, $lon1, $lat2, $lon2): float
    {
        $earthRadius = 6371000; // متر

        $dLat = deg2rad($lat2 - $lat1);
        $dLon = deg2rad($lon2 - $lon1);

        $a = sin($dLat / 2) * sin($dLat / 2) +
            cos(deg2rad($lat1)) * cos(deg2rad($lat2)) *
            sin($dLon / 2) * sin($dLon / 2);

        $c = 2 * atan2(sqrt($a), sqrt(1 - $a));

        return $earthRadius * $c;
    }
}