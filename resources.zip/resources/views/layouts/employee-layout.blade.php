@php
    // صلاحيات موظف النظام
    $employeePermissions = [
        'employee_dashboard',
        'view_employee_tasks',
        'employee_tasks',
        'update_employee_task_progress',
        'view_tasks',
        'edit_tasks',
        'manage_tasks',
        'manage_priorities',
        'create_users',
        'view_users',
        'delete_users',
        'edit_roles',
        'view_roles',
        'delete_roles',
    ];

    // صلاحيات موظف الردود
    $responsePermissions = [
        'view_response_dashboard',
        'view_orders_for_response',
        'update_order_status_to_confirmed_by_response',
        'create_orders_for_customers_as_response',
        'update_order_status',
        'update_order_status_to_preparing',
        'update_order_status_to_ready',
        'update_order_status_to_confirmed',
        'view_orders',
        'delete_laptops',
    ];

    // دالة مساعده لفحص أي صلاحية من مجموعة
    if (!function_exists('hasAnySidebarPermission')) {
        function hasAnySidebarPermission(array $permissions): bool
        {
            $user = auth()->user();
            if (!$user)
                return false;

            foreach ($permissions as $perm) {
                if ($user->hasPermission($perm)) {
                    return true;
                }
            }
            return false;
        }
    }
@endphp

<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <meta charset="utf-8">
    <title>@yield('title', 'لوحة الموظف')</title>

    {{-- Bootstrap --}}
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    {{-- Icons --}}
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">

    <style>
        :root {
            --sidebar-bg: #020617;
            /* خلفية داكنة جداً */
            --sidebar-bg-soft: #0b1120;
            /* طبقة داخلية */
            --sidebar-accent: #22c55e;
            /* أخضر نيون */
            --sidebar-accent-soft: rgba(34, 197, 94, 0.12);
            --sidebar-text: #e5e7eb;
            --sidebar-muted: #9ca3af;
            --sidebar-border: #1f2937;
            --content-bg: #0f172a;
        }

        * {
            box-sizing: border-box;
        }

        body {
            background: radial-gradient(circle at top left, #1e293b 0, #020617 45%, #000 100%);
            font-family: "Tajawal", system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
            color: #e5e7eb;
            min-height: 100vh;
            margin: 0;
        }

        .layout-wrapper {
            display: flex;
            min-height: 100vh;
        }

        /* ================= Sidebar ================= */

        .sidebar {
            position: fixed;
            top: 0;
            right: 0;
            width: 260px;
            height: 100vh;
            background: linear-gradient(160deg, var(--sidebar-bg) 0%, #020617 45%, #020617 100%);
            color: var(--sidebar-text);
            box-shadow: -12px 0 40px rgba(0, 0, 0, 0.65);
            z-index: 1040;
            display: flex;
            flex-direction: column;
            padding: 18px 14px 14px;
            transition: width 0.25s ease, transform 0.25s ease;
        }

        .sidebar-inner {
            border-radius: 16px;
            background: radial-gradient(circle at top, #0b1120 0, #020617 55%);
            border: 1px solid rgba(148, 163, 184, 0.08);
            padding: 10px 10px 12px;
            display: flex;
            flex-direction: column;
            height: 100%;
        }

        .sidebar-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 4px 4px 10px;
            border-bottom: 1px solid rgba(31, 41, 55, 0.9);
            margin-bottom: 8px;
        }

        .sidebar-brand {
            display: flex;
            align-items: center;
            gap: 8px;
            font-weight: 700;
            font-size: 15px;
            letter-spacing: 0.02em;
        }

        .brand-logo {
            width: 30px;
            height: 30px;
            border-radius: 10px;
            background: radial-gradient(circle at 30% 20%, #22c55e 0, #22c55e 22%, #16a34a 60%, transparent 70%),
                radial-gradient(circle at 70% 80%, #4ade80 0, #22c55e 40%, transparent 60%);
            box-shadow: 0 0 16px rgba(34, 197, 94, 0.6);
        }

        .brand-text-main {
            font-size: 14px;
        }

        .brand-text-sub {
            font-size: 11px;
            color: var(--sidebar-muted);
        }

        .sidebar-toggle-desktop {
            border: 1px solid rgba(55, 65, 81, 0.9);
            background: rgba(15, 23, 42, 0.9);
            color: var(--sidebar-muted);
            border-radius: 999px;
            width: 30px;
            height: 30px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            font-size: 14px;
        }

        .sidebar-toggle-desktop:hover {
            border-color: var(--sidebar-accent);
            color: var(--sidebar-accent);
        }

        .sidebar-nav {
            flex: 1;
            margin-top: 6px;
            padding-right: 2px;
            overflow-y: auto;
        }

        .sidebar-section-title {
            font-size: 12px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.14em;
            color: var(--sidebar-muted);
            padding: 12px 10px 6px;
            margin-top: 12px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.08);
        }

        .sidebar-nav a {
            display: flex;
            align-items: center;
            gap: 14px;
            padding: 13px 16px;
            margin: 4px 0;
            text-decoration: none;
            border-radius: 12px;
            color: var(--sidebar-text);
            font-size: 14px;
            position: relative;
            border: 1px solid rgba(255, 255, 255, 0.06);
            background: rgba(255, 255, 255, 0.02);
            transition: background 0.18s ease, color 0.18s ease, border-color 0.18s ease, transform 0.12s ease;
        }

        .sidebar-nav a .menu-icon {
            width: 30px;
            height: 30px;
            border-radius: 9px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            background: rgba(15, 23, 42, 0.76);
            font-size: 16px;
        }

        .sidebar-nav a .menu-label {
            white-space: nowrap;
        }

        .sidebar-nav a:hover {
            background: rgba(34, 197, 94, 0.12);
            border-color: rgba(34, 197, 94, 0.35);
            transform: translateX(-3px);
        }

        .sidebar-nav a.active {
            background: rgba(34, 197, 94, 0.18);
            border-color: rgba(34, 197, 94, 0.7);
            box-shadow: 0 0 10px rgba(34, 197, 94, 0.45);
        }

        .sidebar-nav a.active .menu-icon {
            background: radial-gradient(circle at 30% 20%, #22c55e 0, #22c55e 40%, #16a34a 80%);
            color: #022c22;
            box-shadow: 0 0 10px rgba(34, 197, 94, 0.8);
        }

        .sidebar-footer {
            padding-top: 8px;
            border-top: 1px solid rgba(31, 41, 55, 0.9);
            margin-top: 8px;
        }

        .sidebar-user {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 6px 6px 10px;
        }

        .sidebar-user-avatar {
            width: 32px;
            height: 32px;
            border-radius: 999px;
            background: linear-gradient(135deg, #22c55e, #4ade80);
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 15px;
            font-weight: 700;
            color: #022c22;
        }

        .sidebar-user-info {
            display: flex;
            flex-direction: column;
        }

        .sidebar-user-name {
            font-size: 13px;
            font-weight: 600;
        }

        .sidebar-user-role {
            font-size: 11px;
            color: var(--sidebar-muted);
        }

        .sidebar-logout {
            margin-top: 4px;
        }

        .sidebar-logout a {
            font-size: 12px;
            color: #f97373;
        }

        .sidebar-logout a .menu-icon {
            background: rgba(148, 27, 40, 0.3);
            color: #fecaca;
        }

        .sidebar-logout a:hover {
            background: rgba(127, 29, 29, 0.4);
            border-color: rgba(248, 113, 113, 0.7);
        }

        /* collapsed (desktop) */
        .sidebar.collapsed {
            width: 78px;
        }

        .sidebar.collapsed .brand-text-main,
        .sidebar.collapsed .brand-text-sub,
        .sidebar.collapsed .menu-label,
        .sidebar.collapsed .sidebar-section-title,
        .sidebar.collapsed .sidebar-user-info {
            display: none;
        }

        .sidebar.collapsed .sidebar-nav a {
            justify-content: center;
        }

        .sidebar.collapsed .sidebar-user {
            justify-content: center;
        }

        .sidebar.collapsed .sidebar-toggle-desktop {
            transform: rotate(180deg);
        }

        /* Overlay for mobile drawer */
        .sidebar-overlay {
            position: fixed;
            inset: 0;
            background: rgba(15, 23, 42, 0.65);
            z-index: 1035;
            display: none;
        }

        .sidebar-overlay.show {
            display: block;
        }

        /* ================= Top Navbar ================= */

        .top-navbar {
            position: sticky;
            top: 0;
            z-index: 1030;
            backdrop-filter: blur(16px);
            background: linear-gradient(90deg, rgba(15, 23, 42, 0.86), rgba(15, 23, 42, 0.78));
            border-bottom: 1px solid rgba(30, 64, 175, 0.7);
            padding: 10px 18px;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .top-navbar-title {
            font-weight: 600;
            font-size: 15px;
        }

        .top-navbar-actions {
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .mobile-menu-toggle {
            border-radius: 999px;
            border: 1px solid rgba(148, 163, 184, 0.5);
            width: 32px;
            height: 32px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            background: rgba(15, 23, 42, 0.9);
            color: var(--sidebar-text);
        }

        .mobile-menu-toggle:hover {
            border-color: var(--sidebar-accent);
            color: var(--sidebar-accent);
        }

        /* ================= Content ================= */

        .content-wrapper {
            flex: 1;
            min-height: 100vh;
            margin-right: 260px;
            background: radial-gradient(circle at top, #1f2937 0, #020617 55%, #000 100%);
            transition: margin-right 0.25s ease;
        }

        .content-inner {
            width: 100%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 18px 18px 30px;
        }

        .page-shell {
            background: radial-gradient(circle at top left, rgba(15, 23, 42, 0.96), rgba(15, 23, 42, 0.98));
            border-radius: 18px;
            border: 1px solid rgba(30, 64, 175, 0.45);
            box-shadow: 0 18px 40px rgba(15, 23, 42, 0.9);
            padding: 18px 18px 22px;
        }

        /* ======= Responsive ======= */

        @media (max-width: 991.98px) {
            .sidebar {
                transform: translateX(100%);
                width: 260px;
            }

            .sidebar.open {
                transform: translateX(0);
            }

            .content-wrapper {
                margin-right: 0;
            }

            .top-navbar {
                padding-inline: 12px;
            }

            .content-inner {
                padding-inline: 12px;
            }
        }

        @media (max-width: 767.98px) {
            .content-inner {
                max-width: 100% !important;
                padding: 12px !important;
            }

            .page-shell {
                border-radius: 14px;
                padding: 14px 12px 18px;
            }

            .sidebar-nav a {
                padding: 14px 16px;
                font-size: 15px;
            }

            .sidebar-nav a .menu-icon {
                width: 32px;
                height: 32px;
                font-size: 17px;
            }
        }
    </style>
</head>

<body>

    {{-- Overlay للموبايل --}}
    <div id="sidebar-overlay" class="sidebar-overlay"></div>

    <div class="layout-wrapper">

        {{-- Sidebar --}}
        <aside id="sidebar" class="sidebar">
            <div class="sidebar-inner">

                <div class="sidebar-header">
                    <div class="sidebar-brand">
                        <div class="brand-logo"></div>
                        <div>
                            <div class="brand-text-main">لوحة الموظف</div>
                            <div class="brand-text-sub">BI Laptop Store · Staff</div>
                        </div>
                    </div>

                    <button id="sidebarCollapseBtn" class="sidebar-toggle-desktop d-none d-lg-inline-flex"
                        type="button">
                        <i class="bi bi-chevron-double-right"></i>
                    </button>
                </div>

                <nav class="sidebar-nav">

                    {{-- ========== القسم الأول: الرئيسية ========== --}}
                    @if(
                            hasAnySidebarPermission([
                                'employee_dashboard',
                                'employee_tasks',
                                'view_employee_tasks',
                            ])
                        )
                        <div class="sidebar-section-title">الرئيسية</div>

                        @if(auth()->user()->hasPermission('employee_dashboard'))
                            <a href="{{ route('employee.dashboard') }}"
                                class="{{ request()->routeIs('employee.dashboard') ? 'active' : '' }}">
                                <span class="menu-icon"><i class="bi bi-speedometer2"></i></span>
                                <span class="menu-label">الصفحة الرئيسية</span>
                            </a>
                        @endif

                        @if(auth()->user()->hasPermission('employee_tasks') || auth()->user()->hasPermission('view_employee_tasks'))
                            <a href="{{ route('employee.tasks.index') }}"
                                class="{{ request()->routeIs('employee.tasks.*') ? 'active' : '' }}">
                                <span class="menu-icon"><i class="bi bi-list-check"></i></span>
                                <span class="menu-label">مهامي</span>
                            </a>
                        @endif
                    @endif

                    {{-- ========== القسم الثاني: إدارة النظام ========== --}}
                    @if(
                            hasAnySidebarPermission([
                                'view_users',
                                'create_users',
                                'delete_users',
                                'view_roles',
                                'edit_roles',
                                'delete_roles',
                                'manage_tasks',
                                'manage_priorities',
                                'edit_tasks',
                                'view_tasks',
                            ])
                        )
                        <div class="sidebar-section-title">إدارة النظام</div>

                        {{-- @if(auth()->user()->hasPermission('view_users'))
                            <a href="{{ route('users.index') }}" class="{{ request()->routeIs('users.*') ? 'active' : '' }}">
                                <span class="menu-icon"><i class="bi bi-people"></i></span>
                                <span class="menu-label">المستخدمون</span>
                            </a>
                        @endif

                        @if(auth()->user()->hasPermission('view_roles'))
                            <a href="{{ route('roles.index') }}" class="{{ request()->routeIs('roles.*') ? 'active' : '' }}">
                                <span class="menu-icon"><i class="bi bi-shield-check"></i></span>
                                <span class="menu-label">الأدوار والصلاحيات</span>
                            </a>
                        @endif> --}}

                        {{-- إذا مستقبلاً أضفت Routes لإدارة المهام/الأولويات، أضفها هنا --}}
                    @endif

                    {{-- ========== القسم الثالث: موظف الردود ========== --}}
                    @if(hasAnySidebarPermission($responsePermissions))
                        <div class="sidebar-section-title">موظف الردود</div>

                        @if(auth()->user()->hasPermission('view_response_dashboard'))
                            <a href="{{ route('response.dashboard') }}"
                                class="{{ request()->routeIs('response.dashboard') ? 'active' : '' }}">
                                <span class="menu-icon"><i class="bi bi-speedometer"></i></span>
                                <span class="menu-label">لوحة الردود</span>
                            </a>
                        @endif

                        @if(auth()->user()->hasPermission('view_orders_for_response') || auth()->user()->hasPermission('view_orders'))
                            <a href="{{ route('response.orders.index') }}"
                                class="{{ request()->routeIs('response.orders.*') ? 'active' : '' }}">
                                <span class="menu-icon"><i class="bi bi-bag-check"></i></span>
                                <span class="menu-label">الطلبات</span>
                            </a>
                        @endif

                        @if(auth()->user()->hasPermission('delete_laptops') || auth()->user()->hasPermission('view_laptops'))
                            <a href="{{ route('response.laptops.index') }}"
                                class="{{ request()->routeIs('response.laptops.*') ? 'active' : '' }}">
                                <span class="menu-icon"><i class="bi bi-laptop"></i></span>
                                <span class="menu-label">المنتجات</span>
                            </a>
                        @endif
                    @endif

                </nav>

                {{-- ========== القسم الرابع: الحساب ========== --}}
                <div class="sidebar-footer">
                    <div class="sidebar-section-title">الحساب</div>

                    <div class="sidebar-user">
                        <div class="sidebar-user-avatar">
                            {{ mb_substr(auth()->user()->name ?? 'م', 0, 1) }}
                        </div>
                        <div class="sidebar-user-info">
                            <div class="sidebar-user-name">
                                {{ auth()->user()->name ?? 'موظف' }}
                            </div>
                            <div class="sidebar-user-role">
                                {{ auth()->user()->role->name ?? 'بدون دور' }}
                            </div>
                        </div>
                    </div>

                    <div class="sidebar-logout">
                        <a href="#" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                            <span class="menu-icon"><i class="bi bi-box-arrow-left"></i></span>
                            <span class="menu-label">تسجيل الخروج</span>
                        </a>
                        <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                            @csrf
                        </form>
                    </div>
                </div>

            </div>
        </aside>

        {{-- Content --}}
        <div class="content-wrapper">
            <header class="top-navbar">
                <div class="top-navbar-title">
                    @yield('title', 'لوحة الموظف')
                </div>
                <div class="top-navbar-actions">
                    <button id="mobileMenuBtn" class="mobile-menu-toggle d-lg-none" type="button">
                        <i class="bi bi-list"></i>
                    </button>
                </div>
            </header>

            <main class="content-inner">
                <div class="page-shell">
                    @yield('content')
                </div>
            </main>
        </div>
    </div>

    <script>
        (function () {
            const sidebar = document.getElementById('sidebar');
            const overlay = document.getElementById('sidebar-overlay');
            const mobileBtn = document.getElementById('mobileMenuBtn');
            const desktopCollapseBtn = document.getElementById('sidebarCollapseBtn');

            function openMobileSidebar() {
                if (!sidebar) return;
                sidebar.classList.add('open');
                if (overlay) overlay.classList.add('show');
            }

            function closeMobileSidebar() {
                if (!sidebar) return;
                sidebar.classList.remove('open');
                if (overlay) overlay.classList.remove('show');
            }

            if (mobileBtn) {
                mobileBtn.addEventListener('click', function () {
                    if (sidebar.classList.contains('open')) {
                        closeMobileSidebar();
                    } else {
                        openMobileSidebar();
                    }
                });
            }

            if (overlay) {
                overlay.addEventListener('click', function () {
                    closeMobileSidebar();
                });
            }

            if (desktopCollapseBtn) {
                desktopCollapseBtn.addEventListener('click', function () {
                    sidebar.classList.toggle('collapsed');
                });
            }

            // إغلاق درج الموبايل عند تكبير الشاشة
            window.addEventListener('resize', function () {
                if (window.innerWidth >= 992) {
                    closeMobileSidebar();
                }
            });
        })();
    </script>
        @yield('scripts')
</body>

</html>
