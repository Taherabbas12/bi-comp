<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

    <title>@yield('title', 'لوحة التحكم')</title>

    <!-- Bootstrap RTL -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.rtl.min.css" rel="stylesheet">

    <!-- Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700;800&display=swap" rel="stylesheet">

    <style>
        body {
            background: #f1f4f9;
            font-family: "Tajawal", sans-serif;
        }

        /* ######## Sidebar ######## */
        .sidebar {
            width: 260px;
            background: #111827;
            height: 100vh;
            position: fixed;
            top: 0;
            right: 0;
            padding: 20px;
            color: white;
            overflow-y: auto;
            transition: 0.3s;
        }

        .sidebar h4 {
            font-size: 20px;
            font-weight: 800;
        }

        .sidebar a {
            display: block;
            padding: 14px 18px;
            font-size: 1.1rem;
            color: #d1d5db;
            margin-bottom: 8px;
            border-radius: 10px;
            text-decoration: none;
            font-weight: 500;
            transition: 0.3s;
        }

        .sidebar a:hover,
        .sidebar .active {
            background: #374151;
            color: white;
        }

        .sidebar-section-title {
            font-size: 0.9rem;
            color: #9ca3af;
            margin-top: 20px;
            margin-bottom: 8px;
            border-top: 1px solid #1f2937;
            padding-top: 12px;
            font-weight: 600;
        }

        /* ######## Responsive Sidebar ######## */
        @media (max-width: 820px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
                display: flex;
                overflow-x: auto;
                white-space: nowrap;
                padding: 12px;
            }

            .sidebar a {
                display: inline-block;
                margin-right: 10px;
                font-size: 1rem;
                padding: 10px 16px;
            }

            .sidebar-section-title {
                display: none;
            }

            .content {
                margin-right: 0 !important;
                margin-top: 90px;
            }
        }

        /* ######## Content ######## */
        .content {
            margin-right: 270px;
            padding: 25px;
            transition: 0.3s;
        }

        /* ######## Navbar ######## */
        .navbar {
            background: #ffffff;
            border-bottom: 1px solid #e5e7eb;
            padding: 15px 25px;
            border-radius: 12px;
        }

        .navbar-brand {
            font-size: 1.5rem;
            font-weight: 800;
            color: #111827;
        }

        /* ######## Mobile Optimization ######## */
        @media (max-width: 768px) {
            .navbar-brand {
                font-size: 1.3rem;
            }

            .content {
                padding: 15px;
            }
        }
    </style>

</head>

<body>

    <!-- Sidebar -->
    <div class="sidebar">
        <h4 class="text-center mb-3">👨‍💼 لوحة الموظف</h4>

        {{-- ====== قسم موظف النظام ====== --}}
        @if(
                auth()->user()->can('employee_dashboard') ||
                auth()->user()->can('employee_tasks')
            )
            <div class="sidebar-section-title">
                <i class="bi bi-briefcase"></i> موظف النظام
            </div>
        @endif

        @can('employee_dashboard')
            <a href="{{ route('employee.dashboard') }}"
                class="{{ request()->routeIs('employee.dashboard') ? 'active' : '' }}">
                <i class="bi bi-speedometer2"></i> الرئيسية
            </a>
        @endcan

        @can('employee_tasks')
            <a href="{{ route('employee.tasks.index') }}"
                class="{{ request()->routeIs('employee.tasks.*') ? 'active' : '' }}">
                <i class="bi bi-list-check"></i> مهامي
            </a>
        @endcan

        {{-- ====== موظف الردود ====== --}}
        @if(
                auth()->user()->can('response_dashboard') ||
                auth()->user()->can('response_laptops') ||
                auth()->user()->can('response_orders')
            )
            <div class="sidebar-section-title">
                <i class="bi bi-chat-dots"></i> موظف الردود
            </div>
        @endif

        @can('response_dashboard')
            <a href="{{ route('response.dashboard') }}"
                class="{{ request()->routeIs('response.dashboard') ? 'active' : '' }}">
                <i class="bi bi-speedometer2"></i> لوحة التحكم
            </a>
        @endcan

        @can('response_laptops')
            <a href="{{ route('response.laptops.index') }}"
                class="{{ request()->routeIs('response.laptops.*') ? 'active' : '' }}">
                <i class="bi bi-laptop"></i> المنتجات
            </a>
        @endcan

        @can('response_orders')
            <a href="{{ route('response.orders.index') }}"
                class="{{ request()->routeIs('response.orders.*') ? 'active' : '' }}">
                <i class="bi bi-bag-check"></i> الطلبات
            </a>
        @endcan

        {{-- Logout --}}
        <div class="sidebar-section-title"></div>
        <a href="#" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
            <i class="bi bi-box-arrow-left"></i> تسجيل الخروج
        </a>

        <form id="logout-form" method="POST" action="{{ route('logout') }}" class="d-none">
            @csrf
        </form>
    </div>

    <!-- Main Content -->
    <div class="content">

        <!-- Navbar -->
        <nav class="navbar mb-4">
            <span class="navbar-brand">مرحباً، {{ auth()->user()->name ?? 'موظف' }}</span>
        </nav>

        @yield('content')

    </div>

    {{-- #### مهم جداً: تحميل سكربتات كل صفحة #### --}}
    @yield('scripts')

</body>

</html>
